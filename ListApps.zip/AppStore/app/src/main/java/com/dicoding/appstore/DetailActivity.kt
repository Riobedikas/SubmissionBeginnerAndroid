package com.dicoding.appstore

import android.os.Bundle
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val aplikasiName = intent.getStringExtra("aplikasiName")
        val aplikasiDescription = intent.getStringExtra("aplikasiDescription")
        val aplikasiPhoto = intent.getIntExtra("aplikasiPhoto",R.drawable.discord)

        val photoImageView = findViewById<ImageView>(R.id.detail_aplikasi_photo)
        val nameTextView = findViewById<TextView>(R.id.detail_aplikasi_name)
        val descriptionTextView = findViewById<TextView>(R.id.detail_aplikasi_description)

        photoImageView.setImageResource(aplikasiPhoto)
        nameTextView.text = aplikasiName
        descriptionTextView.text = aplikasiDescription

        // Judul Detail
        title = aplikasiName


    }
    }

