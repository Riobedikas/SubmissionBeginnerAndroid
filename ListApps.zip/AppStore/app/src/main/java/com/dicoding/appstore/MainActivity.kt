package com.dicoding.appstore

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    private lateinit var rvApps: RecyclerView
    private val list = ArrayList<Apps>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvApps = findViewById(R.id.rv_apps)
        rvApps.setHasFixedSize(true)
        list.addAll(getListAplikasi())
        showRecyclerList()
    }

    @SuppressLint("Recycle")
    private fun getListAplikasi(): ArrayList<Apps> {
        val dataName = resources.getStringArray(R.array.data_name)
        val dataDescription = resources.getStringArray(R.array.data_description)
        val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
        val listApps = ArrayList<Apps>()
        for (i in dataName.indices) {
            val apps = Apps(dataName[i], dataDescription[i], dataPhoto.getResourceId(i, -1))
            listApps.add(apps)
        }
        return listApps
    }

    private fun showRecyclerList() {
        rvApps.layoutManager = LinearLayoutManager(this)
        val listAppsAdapter = ListAppsAdapter(list)
        rvApps.adapter = listAppsAdapter
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.about_MenuMainActivity -> {
                val intent = Intent(this, activity_profile::class.java)
                startActivity(intent)
                return true
            }
            else -> return super.onOptionsItemSelected(item)
        }
    }
}
