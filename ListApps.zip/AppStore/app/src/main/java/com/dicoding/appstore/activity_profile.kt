package com.dicoding.appstore

import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import de.hdodenhof.circleimageview.CircleImageView

class activity_profile : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_about)

        // Mengaitkan elemen UI dengan kode Kotlin
        val circleImageViewProfile = findViewById<CircleImageView>(R.id.circleImageViewProfile)
        val textViewName = findViewById<TextView>(R.id.textViewName)
        val textViewEmail = findViewById<TextView>(R.id.textViewEmail)

        // Konten Detail
        circleImageViewProfile.setImageResource(R.drawable.me) // Ganti dengan gambar profil Anda
        textViewName.text = "Rio Bedika Sadewa" // Ganti dengan nama Anda
        textViewEmail.text = "A193BSY2444@bangkit.academy" // Ganti dengan email Anda
    }
}